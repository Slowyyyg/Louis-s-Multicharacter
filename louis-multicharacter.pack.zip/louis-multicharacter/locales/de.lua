return {
    CharacterInformation = {
        title = "Neuen Charakter erstellen",
        subtitle = "Charakterinformationen",
        firstname = "Vorname",
        lastname = "Nachname",
        gender = {
            type = "Geschlecht",
            male = "Männlich",
            female = "Weiblich"
        },
        dob = "Geburtsdatum",
        country = "Nationalität",
        button = "Charakter erstellen"
    },
    Menu = {
        playgame = "Spiel spielen",
        photomode = "Fotomodus",
        store = "Laden",
        credits = "Credits",
        exit = "Spiel beenden",
        createcharacter = {
            title = "Neuen Charakter erstellen",
            subtitle = "verfügbare Plätze"
        }
    },
    PhotoMode = {
        info = "Filter unterscheiden sich je nach Grafikeinstellungen"
    },
    DeleteCharacter = {
        title = "Charakter löschen",
        confirm = "Möchtest du „{name}“ wirklich löschen? Dieser Vorgang kann nicht rückgängig gemacht werden.",
        yes = "Bestätigen",
        no = "Abbrechen"
    },
    Extra = {
        next = "Weiter",
        back = "Zurück",
        free = "Freier Platz",
        hello = "Wähle deinen Charakter",
        pick = "Wähle einen Charakter oder erstelle einen neuen.",
        s1 = "Wie heißt dein Charakter?",
        s1s = "Vor- und Nachname",
        s2 = "Wann wurde er geboren?",
        s2s = "Tag, Monat und Jahr",
        s3 = "Aussehen",
        s3s = "Geschlecht und Größe",
        height = "Größe",
        day = "TT",
        month = "MM",
        year = "JJJJ",
        years = "Jahre alt",
        cash = "Bargeld",
        bank = "Bank",
        job = "Beruf",
        born = "Geboren",
        rank = "Rang",
        spacePlayAction = "Spielen",
        spacePlayStart = "Drück",
        spacePlayEnd = "zum Spielen",
        nameShort = "Mindestens 3 Zeichen",
        nameBad = "Nur Buchstaben, keine Zahlen oder Sonderzeichen",
        dobBad = "Bitte gib ein gültiges Datum ein",
        dobRange = "Das Jahr muss zwischen {a} und {b} liegen",
        creating = "Wird erstellt…",
        close = "Schließen"
    }
}

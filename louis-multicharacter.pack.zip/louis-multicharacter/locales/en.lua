return {
    CharacterInformation = {
        title = "Create New Character",
        subtitle = "Character Information",
        firstname = "First Name",
        lastname = "Last Name",
        gender = {
            type = "Gender",
            male = "Male",
            female = "Female"
        },
        dob = "Date of Birth",
        country = "Nationality",
        button = "Create Character"
    },
    Menu = {
        playgame = "Play Game",
        photomode = "Photo Mode",
        store = "Store",
        credits = "Credits",
        exit = "Exit Game",
        createcharacter = {
            title = "Create New Character",
            subtitle = "avaible slots",
        }
    },
    PhotoMode = {
        info = "Filters differ according to your graphics settings",
    },
    DeleteCharacter = {
        title = "Delete Character",
        confirm = "Do you really want to delete “{name}”? This action cannot be undone.",
        yes = "Confirm",
        no = "Cancel"
    },
    Extra = {
        next = "Continue",
        back = "Back",
        free = "Free slot",
        hello = "Choose your character",
        pick = "Select a character or create a new one.",
        s1 = "What's their name?",
        s1s = "First and last name",
        s2 = "When were they born?",
        s2s = "Day, month and year",
        s3 = "Appearance",
        s3s = "Gender and height",
        height = "Height",
        day = "DD",
        month = "MM",
        year = "YYYY",
        years = "years old",
        cash = "Cash",
        bank = "Bank",
        job = "Job",
        born = "Born",
        rank = "Rank",
        spacePlayAction = "Play",
        spacePlayStart = "Press",
        spacePlayEnd = "to play",
        nameShort = "At least 3 characters",
        nameBad = "Letters only, no digits or special characters",
        dobBad = "Please enter a valid date",
        dobRange = "Year must be between {a} and {b}",
        creating = "Creating...",
        close = "Close"
    }
}

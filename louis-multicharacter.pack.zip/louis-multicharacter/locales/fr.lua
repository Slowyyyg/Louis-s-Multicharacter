return {
    CharacterInformation = {
        title = "Créer un Nouveau Personnage",
        subtitle = "Informations sur le Personnage",
        firstname = "Prénom",
        lastname = "Nom de Famille",
        gender = {
            type = "Genre",
            male = "Homme",
            female = "Femme"
        },
        dob = "Date de Naissance",
        country = "Nationalité",
        button = "Créer le Personnage"
    },
    Menu = {
        playgame = "Jouer",
        photomode = "Mode Photo",
        store = "Boutique",
        credits = "Crédits",
        exit = "Quitter le Jeu",
        createcharacter = {
            title = "Créer un Nouveau Personnage",
            subtitle = "emplacements disponibles"
        }
    },
    PhotoMode = {
        info = "Les filtres varient selon vos paramètres graphiques"
    },
    DeleteCharacter = {
        title = "Supprimer le Personnage",
        confirm = "Voulez-vous vraiment supprimer « {name} » ? Cette action est irréversible.",
        yes = "Confirmer",
        no = "Annuler"
    }
}
